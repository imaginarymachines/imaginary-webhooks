<?php

namespace ImaginaryMachines\Webhooks\Events;
use ImaginaryMachines\Webhooks\Plugin;
use ImaginaryMachines\Webhooks\WebhookEvent;

class SalonUpdated extends WebhookEvent {

    /**
    * @return static
    * @see https://developer.wordpress.org/reference/hooks/post_updated/
    */
    public static function factory():static
	{
		return new self(
            //ID of event
			'ii_salon_updated',
            //Name of event
			'ii Salon Updated',
            //Name of action
			'post_updated',
			3
		);
	}

    public function getPayload(array $args): array
	{
        $post = $this->getPost($args);
		$payload = [
			//Write code here please
		];
		return $payload;
	}

    /**
    * Get post object
    * @param array $args
    * @return\WP_Post|bool
    *
    */
    protected function getPost(array $args)
	{
        //Make sure to check the arguments and update
		if (isset($args[0]) && is_numeric($args[0])) {
			return \get_post($args[0]);
		}
		return false;
	}
    /**
    * @param array $args
    * @return bool
    */
	public function shouldRun(array $args): bool
	{
		$post = $this->getPost($args);
		if( ! $post || ! $this->isPostWebhook($post) ) {
			return false;
		}
		return false;
	}
}
