<?php

namespace ImaginaryMachines\Webhooks\Events;
use ImaginaryMachines\Webhooks\Plugin;
use ImaginaryMachines\Webhooks\WebhookEvent;

class SalonSubmitted extends WebhookEvent {

    /**
    * @return static
    * @see https://developer.wordpress.org/reference/hooks/transition_post_status/
    */
    public static function factory():static
	{
		return new self(
            //ID of event
			'ii_salon_submitted',
            //Name of event
			'ii Salon Submitted',
            //Name of action
			'transition_post_status',
			3
		);
	}

    public function getPayload(array $args): array
	{
        $post = $this->getPost($args);
		$payload = [
			//Write code here please
		];
		return $payload;
	}

    /**
    * Get post object
    * @param array $args
    * @return\WP_Post|bool
    *
    */
    protected function getPost(array $args)
	{
        //Make sure to check the arguments and update
		if (isset($args[1]) && is_object($args[1])) {
			return $args[1];
		}
		if( is_numeric($args[0]) ) {
			return \get_post($args[0]);
		}

		return false;
	}
    /**
    * @param array $args
    * @return bool
    */
	public function shouldRun(array $args): bool
	{
		$post = $this->getPost($args);
		if( ! $post || ! $this->isPostWebhook($post) ) {
			return false;
		}
		$new_status = $args[0];
		$old_status = $args[1];
		// Early bail: We are looking for published posts only
		if ( $new_status != 'publish' || $old_status == 'publish' ) {
			return false;
		}
		return true;
	}
}
