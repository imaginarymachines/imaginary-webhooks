<?php

namespace ImaginaryMachines\Webhooks;

class event {

}
